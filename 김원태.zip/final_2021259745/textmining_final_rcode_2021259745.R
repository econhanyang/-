install.packages("ggthemes")
install.packages("ggplot2")
suppressPackageStartupMessages({
  library(ggplot2)
  library(ggthemes)
})

#�⺻ �׸����� �ѱ� ��Ʈ ���Ǹ� �ϰ� �ʹٸ� �Ʒ� �ڵ常 �����Ѵ�. 
theme_set(theme_gray(base_family='NanumGothic'))


install.packages("rJava", "RWeka")
install.packages("rJava")
install.packages("KoNLP") 
install.packages("data.table")
install.packages("tm")
install.packages("dplyr")
install.packages("tidytext")
install.packages("stringr")
install.packages("tidyr")
install.packages("igraph")
install.packages("ggraph")
install.packages("RColorBrewer") 
install.packages("wordcloud")
install.packages("wordcloud2")
install.packages("Rcurl")
library(httr)
set_config(config(ssl_verifypeer = 0L))
install.packages("devtools")
library(devtools)
install.packages("widyr")
install_github("dgrtwo/widyr")
install.packages("formattable") #for nicer data table
install.packages("extrafont")
library(extrafont)

vignette("KoNLP-API") 
library("curl")


library("rJava", "RWeka")
library(KoNLP)
library(data.table)
library(tm)
library(dplyr)
library(tidytext)
library(stringr)
library(tidyr)
library(igraph)
library(ggraph)
library(RColorBrewer) 
library(wordcloud)
library(wordcloud2)
library(widyr) #for word correlation
library(formattable) #for nicer data table
library(extrafont)
font_import()
vignette("KoNLP-API") 


install.packages("multilinguer")
install.packages("devtools")
library(multilinguer)
install.packages("devtools")
require(devtools)

install.packages(c('stringr', 'hash', 'tau', 'Sejong', 'RSQLite'), type = "binary")
install.packages("remotes")
remotes::install_github('haven-jeon/KoNLP', upgrade = "never", INSTALL_opts=c("--no-multiarch"))
library(KoNLP)


options(java.parameters = "-Xmx7g" )

comment <- read.csv("C:/Users/goqud/Desktop/evaluation.csv",header = TRUE)

sum(!is.na(comment$request))
#check the feedback types
unique(comment$request)

comment <- comment[!is.na(comment$request), ]

comment$request <- gsub("\n","", comment$request)
comment$request <- gsub("\r", "", comment$request)
comment$request <- gsub("'", "", comment$request)  # remove apostrophes
comment$request <- gsub("[[:punct:]]", " ", comment$request)  # replace punctuation with space
comment$request <- gsub("[[:cntrl:]]", " ", comment$request)  # replace control characters with space
comment$request <- tolower(comment$request)  # force to lowercase
#comment$request <- gsub("����","", comment$request)
comment$request <- gsub("�����ϴ�","", comment$request)

for (i in 1:dim(comment)[1]) {
  if (!is.na(comment$request[i]) & nchar(comment$request[i]) > 5) {
    l <- extractNoun(comment$request[i])
    l <- l[lapply(l, nchar) > 1]
    comment$new.comment[i] <- paste(l, collapse=' ')
  } else {
    comment$new.comment[i] <- ""  
  }
}

comment$new.comment <- gsub("�𸣰�","", comment$new.comment)

Corpus <- paste(comment[which(comment$new.comment != "") ,"new.comment"], collapse = " ")
# how many characters
nchar(Corpus)
# make a vector comprised of token(noun)
wordsvec <- unlist(strsplit(Corpus, split=" "))
length(wordsvec)

wordsvec <- Filter(function(x){nchar(x)>=2}, wordsvec)
wordscount <- table(wordsvec)
wordscount <- as.data.frame(wordscount)

#ggplot bar chart
wordscount %>% 
  arrange(desc(Freq)) %>%
  top_n(20) %>% 
  ungroup %>%
  ggplot(aes(x = reorder(wordsvec, Freq), y = Freq)) +
  geom_col(show.legend = FALSE) +
  labs(x = NULL, y = "Term Frequency") +
  coord_flip()

bigrams <- comment
bigrams$bigram <- NA
for (i in 1:dim(comment)[1]) {
  if (!is.na(bigrams$new.comment[i]) & nchar(bigrams$new.comment[i]) > 2) {  
    bi.list <- unlist(lapply(ngrams(words(bigrams$new.comment[i]), 2), paste, collapse = " "), use.names = FALSE)
    if (!is.null(bi.list)) {
      bi.list <- paste(bi.list, collapse=',')
      #      print(bi.list)
      bigrams$bigram[i] <- bi.list
    }
  }
}

bigrams <- bigrams %>%
  unnest(bigram = strsplit(bigram, ","))
bigrams <- bigrams[!(is.na(bigrams$bigram)),]

bigrams_count <- bigrams %>% 
  count(bigram, sort = TRUE)

#ggplot bigram tf bar chart
bigrams_count %>% 
  arrange(desc(n)) %>%
  top_n(20) %>% 
  ungroup %>%
  ggplot(aes(x = reorder(bigram, n), y = n)) +
  geom_col(show.legend = FALSE) +
  labs(x = NULL, y = "Term Frequency") +
  coord_flip()


bigrams_count %>%
  top_n(20)

bigrams_separated <- bigrams %>%
  separate(bigram, c("word1", "word2"), sep = " ")

bigrams_filtered <- bigrams_separated %>%
  filter(nchar(word1)>1) %>%
  filter(nchar(word2)>1)

# new bigram counts:
bigram_counts <- bigrams_filtered %>% 
  count(word1, word2, sort = TRUE)

bigram_counts %>%
  top_n(30)

#bigram graph

bigram_graph <- bigram_counts %>%
  arrange(desc(n)) %>%
  top_n(20) %>% 
  # filter(n > 30) %>%
  graph_from_data_frame()
bigram_graph 


set.seed(2017)
#graph type 1
a <- grid::arrow(type = "closed", length = unit(.15, "inches"))
set_graph_style(family = "AppleGothic", face = "plain", size = 10, text_size = 12, text_colour = "black")
ggraph(bigram_graph, layout = "fr") +
  geom_edge_link(aes(edge_alpha = n), show.legend = FALSE,
                 arrow = a, end_cap = circle(.07, 'inches')) +
  geom_node_point(color = "lightblue", size = 5) +
  geom_node_text(aes(label = name), vjust = 1, hjust = 1) +
  theme_void()

comment.keywords <- comment %>%
  unnest_tokens(keyword, new.comment) %>%
  filter(!keyword %in% stop_words$word)

# count words co-occuring within the same feedback (graph type2)
word_pairs <- comment.keywords %>%
  pairwise_count(keyword, request, sort = TRUE)

word_pairs %>%
  top_n(30)

word_pairs %>%
  #filter(item1 == "") %>%
  top_n(30) %>% 
  #  filter(n <= 300) %>%
  graph_from_data_frame() %>%
  ggraph(layout = "fr") +
  geom_edge_link(aes(edge_alpha = n, edge_width = n), edge_colour = "darkred") +
  geom_node_point(size = 5) +
  geom_node_text(aes(label = name), repel = TRUE,
                 point.padding = unit(0.2, "lines")) +
  theme_void()

# graph type 3
bigram_counts %>%
  filter(word1 == "����") %>%
  top_n(20) %>%
  graph_from_data_frame() %>%
  ggraph(layout = "fr") +
  geom_edge_link(aes(edge_alpha = n, edge_width = n), arrow = a, edge_colour = "cyan4", end_cap = circle(.07, 'inches')) +
  geom_node_point(size = 5) +
  geom_node_text(aes(label = name), repel = TRUE, 
                 point.padding = unit(0.2, "lines")) +
  theme_void()

#�ܾ ���
word_cors <- comment.keywords %>%
  group_by(keyword) %>%
  filter(n() >= 1) %>%
  pairwise_cor(keyword, request, sort = TRUE)

bigrams$class <- bigrams$level
bigrams$class[bigrams$class==""] <- "NA"
bigrams$class[is.na(bigrams$class)] <- "NA"
bigrams$class[bigrams$class==" "] <- "NA"

#------�׷캰 �ܾ� ī��Ʈ------------
comment.word <- bigrams %>%
  unnest_tokens(word, new.comment) %>%
  count(class, word, sort=TRUE) %>%
  ungroup()

total.word <- comment.word %>%
  group_by(class) %>%
  summarise(total = sum(n))

comment.word <- left_join(comment.word, total.word)

total <- sum(wordscount$Freq)

#term frequencies
for (i in 1:dim(wordscount)[1]) {
  comment.word$tf[i]<-wordscount$Freq[i]/total  
}

#by frequency
a <- comment.word %>% 
  group_by(class) %>% 
  arrange(desc(tf)) %>%
  top_n(12) %>% 
  ungroup %>%
  ggplot(aes(x = reorder(wordsvec, tf), y = tf)) +
  geom_col(show.legend = FALSE) +
  labs(x = NULL, y = "Term Frequency") +
  facet_wrap(~class, ncol = 3, scales = "free") +
  coord_flip()

#tf-idf
comment.word.tf_idf <- comment.word %>%
  bind_tf_idf(word, class, n)

comment.word.tf_idf <- comment.word.tf_idf %>%
  group_by(class) %>%
  arrange(tf_idf) %>%
  mutate(tf_idf_rank = row_number())

comment.word.tf_idf %>% 
  group_by(class) %>% 
  arrange(desc(tf_idf)) %>%
  top_n(n=30, wt=tf_idf_rank) %>% 
  ungroup %>%
  ggplot(aes(x = reorder(word, tf_idf), y = tf_idf, fill = class)) +
  geom_col(show.legend = FALSE) +
  labs(x = NULL, y = "tf-idf") +
  facet_wrap(~class, ncol = 3, scales = "free") +
  coord_flip()

tf_idf_table <- comment.word.tf_idf %>% 
  group_by(class) %>% 
  arrange(desc(tf_idf)) %>%
  top_n(n=30, wt=tf_idf_rank)

write.csv(tf_idf_table,"C:/Users/goqud/Desktop/evaluation.csv", row.names = TRUE)

# factor_class
comment.word.tf_idf %>%
  group_by(class) %>% 
  arrange(desc(n)) %>%
  top_n(30) %>% 
  ggplot(aes(tf, tf_idf, label = word)) +
  geom_label(aes(fill = factor(class)), colour = "white", fontface = "bold")

bigrams_separated <- bigrams %>%
  separate(bigram, c("word1", "word2"), sep = " ")

bigram_counts <- bigrams_separated %>% 
  count(word1, word2, sort = TRUE)
bigram_counts %>% 
  top_n(100)

# unite bigrams
bigrams_united <- bigrams_separated %>%
  unite(bigram, word1, word2, sep = " ")

#creating bigram tf_idf
bigram_tf_idf <- bigrams_united %>%
  count(class, bigram) %>%
  bind_tf_idf(bigram, class, n) %>%
  arrange(desc(tf_idf))

bigram_tf_idf %>%
  top_n(100)

write.csv(bigram_tf_idf,"C:/Users/goqud/Desktop/evaluation.csv", row.names = TRUE)

#by frequency
bigram_tf_idf <- bigram_tf_idf %>%
  group_by(class) %>%
  arrange(tf) %>% 
  mutate(tf_rank = row_number())

bigram_tf_idf_table<-bigram_tf_idf %>% 
  group_by(class) %>% 
  arrange(desc(tf)) %>%
  top_n(30) %>% 
  ungroup

